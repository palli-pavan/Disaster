ReliefPlan AI final report and project submission

GitHub repository
https://github.com/palli-pavan/Disaster

Contents
- ReliefPlan_AI_Final_Report.docx: revised report with black bold headings,
  unnumbered source code, verified results and four dashboard figures.
- dashboards/: original full page screenshots of the running React application.
- emergency-resource-allocation/: Python and React source, data, saved models and tests.
- evidence/: captured output, verification notes and reproduction script.
- SHA256SUMS.txt: checksums for every other packaged file.

Python setup from emergency-resource-allocation
  python -m venv .venv
  .\.venv\Scripts\Activate.ps1
  python -m pip install -r requirements.txt
  python -m pip install fastapi uvicorn
  python -m pytest tests -v

Run the API from emergency-resource-allocation
  python -m uvicorn api:app --host 127.0.0.1 --port 8000

Run the React frontend in a second terminal from frontend
  npm ci
  npm run dev -- --host 127.0.0.1

Streamlit alternative from emergency-resource-allocation
  streamlit run app/Home.py

Reproduce the captured core and handler outputs from the extracted archive root
  python evidence/capture_outputs.py

The report distinguishes the ten area core baseline, API defaults and the
seven area React screenshot scenario. Dashboard capture inputs are recorded
in evidence/dashboard_capture.json. Read the limitations before interpreting
screen claims about minimum allocation, stock quantities or dispatch actions.

Dependencies, caches and generated frontend build files are excluded.
Saved models are already included; retraining replaces model and metric files.
