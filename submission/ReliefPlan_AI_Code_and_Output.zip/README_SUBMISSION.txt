ReliefPlan AI code and output submission

Contents
- ReliefPlan_AI_Project_Submission.docx: implementation report and selected code listings
- emergency-resource-allocation/: complete supplied source, CSV data, trained models and tests
- evidence/: captured JSON output, allocation CSVs and reproduction script
- SHA256SUMS.txt: checksums for all other packaged files

Run the project from emergency-resource-allocation.

Python setup in PowerShell
  python -m venv .venv
  .\.venv\Scripts\Activate.ps1
  python -m pip install -r requirements.txt
  python -m pip install fastapi uvicorn
  python -m pytest tests -v

React interface
  python -m uvicorn api:app --host 127.0.0.1 --port 8000
In another terminal, enter emergency-resource-allocation/frontend:
  npm ci
  npm run dev -- --host 127.0.0.1

Streamlit alternative
  streamlit run app/Home.py

Reproduce outputs from the extracted archive root
  python evidence/capture_outputs.py

The reproduction script uses installed project dependencies and writes new output
to evidence. It appends verification records to a separate audit file.
Saved model artifacts are already supplied. Optional retraining with
python core/model.py replaces models and metrics.

Read the report limitations before demonstrating the prototype. In particular,
API stock inputs currently do not update allocation supply; the displayed
25 percent floor is not enforced; simulation reloads its own default baseline;
dispatch and broadcast buttons only change client state.

Original README files and earlier modules are preserved as source material.
The report describes the current code and distinguishes core and API results.
Generated frontend dist, node_modules, Python caches and QA renders are excluded.
